var Style1 = true; 
var Style2 = false; 
