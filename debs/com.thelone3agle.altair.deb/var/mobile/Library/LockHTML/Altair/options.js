var Epic = true; 
var Epicc = false; 
var hidden = true; 
