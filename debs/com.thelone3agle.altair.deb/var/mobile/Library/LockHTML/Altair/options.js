var Style1 = true; 
var Style2 = false; 
var Style3 = false;
